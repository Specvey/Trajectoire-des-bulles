import java.util.ArrayList;

public class Main
{
	public static void main(String args[])
	{
		/**
		 * Fichier d'entree contenant les coordonnees des points
		 */
		String entree = "norma_N5_tau4_dt2_delai820_000003";
		
		Resolution r = new Resolution("data/"+entree+".txt");
		ArrayList<Point[]> trajectoires = r.deroulement();
		
		/**
		 * Creation du fichier de sortie avec les trajectoires
		 * Les points dans les trajectoires sont representes par leur numero de ligne dans le fichier d'entree
		 */
		r.writeData("data/"+entree+"RESULT.txt",trajectoires);
		
		/**
		 * Affichage du graphe avec une coloration rouge pour les trajectoires trouvees
		 */
		r.afficherGraphe(trajectoires);
	}
}