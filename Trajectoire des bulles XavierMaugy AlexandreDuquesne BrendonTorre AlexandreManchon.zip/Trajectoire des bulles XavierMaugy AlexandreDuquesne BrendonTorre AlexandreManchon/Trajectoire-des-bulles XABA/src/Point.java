import java.util.ArrayList;

public class Point 
{
	private double x;
	private double y;
	private double z;
	
	/**
	 * L'id du Point correspond a son numero de ligne dans le fichier d'entree
	 */
	private int id;
	
	/**
	 * Liste de tous les points tries du point le + proche au point le plus eloigne
	 */
	private ArrayList<Point> voisins;
	
	/**
	 * Liste de voisins ne prenant qu'un pourcentage des meilleurs
	 */
	private ArrayList<Point> meilleursVoisins;
	
	public Point(double x, double y, double z, int id)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		this.id = id;
	}
	
	public Point(Point p)
	{
		this.x = p.getX();
		this.y = p.getY();
		this.z = p.getZ();
		this.id = p.getId();
	}
	
	public double getX()
	{
		return this.x;
	}
	
	public double getY()
	{
		return this.y;
	}
	
	public double getZ()
	{
		return this.z;
	}
	
	public int getId()
	{
		return this.id;
	}
	
	public boolean isEqual(Point p)
	{
		if(x==p.getX() && y==p.getY() && z==p.getZ())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void setVoisins(ArrayList<Point> v)
	{
		voisins = new ArrayList<Point>(v);
	}
	
	public void setMeilleursVoisins(ArrayList<Point> v)
	{
		meilleursVoisins = new ArrayList<Point>(v);
	}
	
	public ArrayList<Point> getVoisins()
	{
		return voisins;
	}
	
	public ArrayList<Point> getMeilleursVoisins()
	{
		return meilleursVoisins;
	}
	
	public String toString()
	{
		return x+" "+y+" "+z;
	}
}
