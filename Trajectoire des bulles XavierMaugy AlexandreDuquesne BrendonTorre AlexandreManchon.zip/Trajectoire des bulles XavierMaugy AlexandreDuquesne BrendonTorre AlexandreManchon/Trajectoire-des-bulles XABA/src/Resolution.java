import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;

public class Resolution
{
	/**
	 * Liste de tous les points
	 */
	private ArrayList<Point> points = new ArrayList<Point>();
	
	/**
	 * Parametres permettant d'ajuster la recherche des trajectoires dans l'algorithme
	 */
	private double pourcentageDistance = 0.01;
	private double pasPourcentageDistance = 0.01;
	private double pourcentageDistanceMax = 0.45;
	private double angleDegre =  20;
	private double nbreDeVoisinsAGarder = 0.1;
	
	/**
	 * Lecture du fichier d'entree et initialisation des voisins pour chaque point
	 * @param nomFichier
	 */
	public Resolution(String nomFichier)
	{
		lectureFichier(nomFichier);
		attribuerVoisins();
	}

	/**
	 * A partir d'un fichier, on cree l'arraylist de points.
	 * Chaque point a des coordonnees x y z.
	 */
	public void lectureFichier(String nomFichier)
	{
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		String ligneFichier;
		double x, y, z;
		int id = 1;
		try
		{
			fis = new FileInputStream(new File(nomFichier));
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			// Tant que l'on est pas à la fin du fichier, on continue à lire
			while((ligneFichier = br.readLine()) != null)
			{
				String[] split = ligneFichier.split("   ");
				x = convertStringEnDouble(split[1]);
				y = convertStringEnDouble(split[2]);
				z = convertStringEnDouble(split[3]);

				points.add(new Point(x, y, z, id));
				id++;
			}
			br.close();
		}
		catch(FileNotFoundException e) // Si aucun fichier n'a été trouvé
		{
			e.printStackTrace();
		}
		catch(IOException e) // Si erreur d'écriture ou de lecture
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(fis != null)
				{
					fis.close();
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Initialisation des listes voisins et meilleursVoisins pour chaque point
	 */
	public void attribuerVoisins()
	{
		for(Point p: points)
		{
			voisins(p);
			meilleursVoisins(p);
		}
	}
	
	/**
	 * Affichage du graphe avec une coloration rouge pour les trajectoires trouvees
	 * @param trajectoires
	 */
	public void afficherGraphe(ArrayList<Point[]> trajectoires)
	{
		// On crée le graphe
		Graph g = new SingleGraph("Graphe");
		g.addAttribute("ui.stylesheet", "url('data/style.css')");
		
		for(Point p:points)
		{//Z
			// On crée un noeud avec ses coordonées :
			g.addNode(""+p.getId());
			g.getNode(""+p.getId()).addAttribute("x",p.getX());
			g.getNode(""+p.getId()).addAttribute("y",p.getY());
			g.getNode(""+p.getId()).addAttribute("z",p.getZ());
			//g.getNode(""+p.getId()).addAttribute("ui.label",""+p.getId());
		}
		
		int idEdge = 0;
		Node noeud1;
		Node noeud2;
		// Pour chaque trajectoire
		for(Point[] trajectoire:trajectoires)
		{
			// Pour chaque point de la trajectoire
			for(int i=0;i<4;i++)
			{
				noeud1 = g.getNode(""+trajectoire[i].getId());
				noeud2 = g.getNode(""+trajectoire[i+1].getId());
				noeud1.addAttribute("ui.style", "fill-color: red;");
				noeud2.addAttribute("ui.style", "fill-color: red;");
				g.addEdge(""+idEdge, noeud1, noeud2);
				idEdge++;
			}
		}
		g.display(false);
	}
	
	
	public double convertStringEnDouble(String texte)
	{
		String[] split = texte.split("e");

		double a = Double.parseDouble(split[0]);
		double puissance = Double.parseDouble(split[1].substring(0, split[1].length()));
		return a*Math.pow(10,puissance);
	}

	public void afficherLesPoints()
	{
		for(Point p:points)
		{
			System.out.println(p.toString());
		}
	}
	
	/**
	 * Convertisseur d'angle radian en degre
	 * @param p1
	 * @param p2
	 * @param p3
	 * @return angle en degre
	 */
	public double calculAngleDegre(Point p1, Point p2, Point p3)
	{
		return Math.toDegrees(calculAngleRadian(p1, p2, p3));
	}
	
	/**
	 * Calcul d'un angle a partir de 3 points
	 * @param p1
	 * @param p2
	 * @param p3
	 * @return angle en radian
	 */
	public double calculAngleRadian(Point p1, Point p2, Point p3)
	{
		double b = calculDistance(p1, p2);
		double a = calculDistance(p2, p3);
		double c = calculDistance(p1, p3);

		double res = Math.acos((Math.pow(c, 2) - Math.pow(a, 2) - Math.pow(b, 2))/(-2*a*b));

		return res;
	}
	
	/**
	 * Calcul de la distance entre deux points
	 * @param a
	 * @param b
	 * @return
	 */
	public double calculDistance(Point a, Point b)
	{
		double res = Math.sqrt(Math.pow((b.getX() - a.getX()), 2) + Math.pow((b.getY() - a.getY()), 2));
		return res;
	}
	
	
	public void voisins(Point pO) 
	{
		ArrayList<Point> voisinage = new ArrayList<Point>();

		for(Point pV : points)
		{
			if(!pO.isEqual(pV))
			{
				voisinage.add(pV);
			}
		}

		tri(voisinage, pO);

		pO.setVoisins(voisinage);
	}

	public void meilleursVoisins(Point pO) 
	{

		ArrayList<Point> voisinage = new ArrayList<Point>();
		ArrayList<Point> meilleursVoisins = new ArrayList<Point>();

		for(Point pV : points)
		{
			if(!pO.isEqual(pV))
			{
				voisinage.add(pV);
			}
		}

		tri(voisinage, pO);


		for(int i = 0; i < (int)(nbreDeVoisinsAGarder*points.size()); i++)
		{
			meilleursVoisins.add(voisinage.get(i));
		}

		pO.setMeilleursVoisins(meilleursVoisins);

	}

	
	public ArrayList<Point> tri(ArrayList<Point> al, Point pO)
	{
		Collections.sort(al, new Comparator<Point>(){
			public int compare(Point p1, Point p2)
			{
				double comp = Double.compare(calculDistance(pO, p1), calculDistance(pO, p2));

				if(comp < 0)
				{
					return -1;
				}
				else if(comp > 0)
				{
					return 1;
				}
				else
				{
					return 0;
				}

			}
		});
		return al;
	}
	
	public void afficheAngles(ArrayList<Point[]> trajectoires)
	{
		int nTraj = 1;
		for(Point[] trajectoire:trajectoires)
		{
			System.out.println("Trajectoire n°"+nTraj);
			for(int i=0;i<5;i++)
			{
				System.out.println("p"+(i+1)+" = "+trajectoire[i].getId());
			}
			System.out.println("Angle en p2 = "+calculAngleDegre(trajectoire[0],trajectoire[1],trajectoire[2]));
			System.out.println("Angle en p3 = "+calculAngleDegre(trajectoire[1],trajectoire[2],trajectoire[3]));
			System.out.println("Angle en p4 = "+calculAngleDegre(trajectoire[2],trajectoire[3],trajectoire[4]));
			nTraj++;
		}
	}
	
	/**
	 * Methode principale du programme contenant l'algorithme de recherche de trajectoires
	 * @return la liste des trajectoires trouvees
	 */
	public ArrayList<Point[]> deroulement()
    {
            Point [] trajectoire;
            ArrayList<Point> pointsRestants = new ArrayList<Point>();
            ArrayList<Point[]> trajectoires = new ArrayList<Point[]>();
            double distanceP12;
            double angle;
            double distance;
            boolean trajectoireTrouve = false;
            
            Point p1;
            int i1, i2, i3, i4;
            
            // On recopie points dans pointsRestants
            for(Point p:points)
            {
                    pointsRestants.add(p);
            }
            
            while(pourcentageDistance < pourcentageDistanceMax)
            {
                    for(i1 = 0;i1<pointsRestants.size();i1++)
                    {
                            trajectoireTrouve = false;
                            trajectoire = new Point[5];
                            p1 = pointsRestants.get(i1);
                            pointsRestants.remove(i1);
                            trajectoire[0]= p1;

                            for(Point p2:p1.getMeilleursVoisins())
                            {
                            	if(pointsRestants.indexOf(p2)!=-1)
                            	{
                                i2 = pointsRestants.indexOf(p2);
                                    pointsRestants.remove(p2);
                                    trajectoire[1]= p2;
                                    distanceP12 = calculDistance(p1, p2);
                                    for(Point p3:p2.getMeilleursVoisins())
                                    {
                                    	if(pointsRestants.indexOf(p3)!=-1)
                                    	{
                                          i3 = pointsRestants.indexOf(p3);
                                            pointsRestants.remove(p3);
                                            trajectoire[2]= p3;
                                            // On regarde si p3 est possible pour la distance et pour l'angle
                                            // Si p3 est possible, on continue
                                            angle = calculAngleDegre(p1,p2,p3);
                                            distance = calculDistance(p2, p3);
                                            if(distance > distanceP12*(1-pourcentageDistance) && distance < distanceP12*(1+pourcentageDistance) && angle > 180 - angleDegre && angle < 180 + angleDegre )
                                            {
                                                    for(Point p4:p3.getMeilleursVoisins())
                                                    {
                                                    	if(pointsRestants.indexOf(p4)!=-1)
                                                    	{
                                                         i4 = pointsRestants.indexOf(p4);
                                                            pointsRestants.remove(p4);
                                                            trajectoire[3]= p4;
                                                            // On regarde si p4 est possible pour la distance et pour l'angle
                                                            // Si p4 est possible, on continue
                                                            angle = calculAngleDegre(p2,p3,p4);
                                                            distance = calculDistance(p3, p4);
                                                            if(distance > 2*distanceP12*(1-pourcentageDistance) && distance < 2*distanceP12*(1+pourcentageDistance) && angle > 180 - 2*angleDegre && angle < 180 + 2*angleDegre )
                                                            {
                                                                    for(Point p5:p4.getMeilleursVoisins())
                                                                    {
                                                                    	if(pointsRestants.indexOf(p5)!=-1)
                                                                    	{
                                                                            trajectoire[4]= p5;
                                                                            // On regarde si p5 est possible pour la distance et pour l'angle
                                                                            // Si p5 est possible, on a trouvé une nouvelle trajectoire que l'on ajoute
                                                                            angle = calculAngleDegre(p3,p4,p5);
                                                                            distance = calculDistance(p4, p5);
                                                                            if(distance > distanceP12*(1-pourcentageDistance) && distance < distanceP12*(1+pourcentageDistance) && angle > 180 - angleDegre && angle < 180 + angleDegre )
                                                                            {
                                                                                    trajectoires.add(trajectoire);
                                                                                    System.out.println("Nombre de trajectoires trouvées : "+trajectoires.size());
                                                                                    pointsRestants.remove(p5);
                                                                                    i1--;
                                                                                    trajectoireTrouve = true;
                                                                            } //if p5
                                                                            if(trajectoireTrouve) break;
                                                                    	}
                                                                    }//for p5
                                                            }//if p4
                                                            if(trajectoireTrouve) break;
                                                            else pointsRestants.add(i4,p4);
                                                    	}
                                                    }//for p4
                                            }//if p3
                                            if(trajectoireTrouve) break;
                                            else pointsRestants.add(i3,p3);
                                    	}
                                    }// for p3
                                    if(trajectoireTrouve) break;
                                    else pointsRestants.add(i2,p2);
                            	}
                            }// for p2
                            if(!trajectoireTrouve) pointsRestants.add(i1, p1);
                    }//for p1
                    pourcentageDistance += pasPourcentageDistance;
            }// while
            return trajectoires;
    }
	
	/**
	 * Creation d'un fichier de sortie contenant toutes les trajectoires trouvees
	 * Les points dans les trajectoires sont representes par leur numero de ligne dans le fichier d'entree
	 * @param filename
	 * @param trajectoires
	 */
	public void writeData(String filename, ArrayList<Point[]> trajectoires)
    {
        if(trajectoires.size() != 0)
        {
            File f = new File(filename);
            Point[] tabTmp;
            try
            {
                FileWriter fw = new FileWriter(f);
                for (int i = 0; i < trajectoires.size(); i++)
                {
                	tabTmp = trajectoires.get(i);
                	for(int j = 0; j < 5; j++){
                		 
                		 fw.write(String.valueOf(tabTmp[j].getId()));
                         fw.write(" ");
                	}
                    fw.write("\n");
                }
                fw.close();
            }
            catch(IOException exception)
            {
                System.out.println("Erreur lors de la lecture : " + exception.getMessage());
            }
        }
    }
	
}
